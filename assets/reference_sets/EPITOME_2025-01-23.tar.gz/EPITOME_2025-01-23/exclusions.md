|taxon              | exclusions|reason                                                     |
|:------------------|----------:|:----------------------------------------------------------|
|Betainfluenzavirus |          5|Mislabelled as Flu B                                       |
|Orthopneumovirus   |        627|Subtype from Fasta Header doesn't match Subtype from Blast |
