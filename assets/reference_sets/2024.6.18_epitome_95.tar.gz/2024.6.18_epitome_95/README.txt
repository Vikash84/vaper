Created by Jared Johnson on 6/18/2024

# Reference sets
Influenza A (segments 1-8)
Influenza B (segments 1-8)
Measles morbillivirus
Mumps orthorubulavirus
Lyssavirus rabies
Norovirus
Respiratory Syncytial Virus (RSV)
West Nile virus
Enterovirus D68
Hepacivirus (HCV)
Hepatovirus (HAV)

# Known Issues
- Influenza A references "Influenza_A-seg-8_NS-41" and "Influenza_A-seg-7_MP-17" were removed from this reference set after discovering that the GISAID sequences (EPI1392734, B/Iquique/58107/2018|NS|8 and EPI1392735, B/Iquique/58107/2018|MP|7) used to create them were erroneously submitted as Influenza A.  
