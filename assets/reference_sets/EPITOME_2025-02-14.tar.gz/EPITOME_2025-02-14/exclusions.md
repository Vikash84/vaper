|taxon            | exclusions|reason                                                     |
|:----------------|----------:|:----------------------------------------------------------|
|Alphainfluenza   |          8|Ambiguous taxonomy                                         |
|Orthopneumovirus |        627|Subtype from Fasta Header doesn't match Subtype from Blast |
