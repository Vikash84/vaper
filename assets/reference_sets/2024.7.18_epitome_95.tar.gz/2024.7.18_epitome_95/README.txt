Created by Jared Johnson on 7/18/2024

# Reference sets
**Taxon**|**Segments**|**Input Sequences**|**Data Source**
-----|-----|-----|-----
Influenza A|1-8|78703 (per segment)|GISAID
Influenza B|1-8|17401 (per segment)|GISAID
Measles morbillivirus|wg|890|NCBI
Mumps orthorubulavirus|wg|1343|NCBI
Lyssavirus rabies|wg|2607|NCBI
Norovirus|wg|1662|NCBI
Respiratory Syncytial Virus|wg|15273|GISAID
West Nile virus|wg|1993|NCBI
Enterovirus D68|wg|590|NCBI
Hepacivirus|wg|1245|NCBI
Hepatovirus|wg|131|NCBI
Monkeypox virus|wg|2129|NCBI
Severe acute respiratory syndrome coronavirus|wg|2000 (random)|NCBI

# Known Issues
- Influenza A references "Influenza_A-seg-8_NS-41" and "Influenza_A-seg-7_MP-17" were removed from this reference set after discovering that the GISAID sequences (EPI1392734, B/Iquique/58107/2018|NS|8 and EPI1392735, B/Iquique/58107/2018|MP|7) used to create them were erroneously submitted as Influenza A.  
